<?php

// Les codes couleur
const BLUE = "\033[34m" ;
const YELLOW = "\033[33m" ;
const GREEN = "\033[32m" ;
const RED = "\033[31m" ;
const RESET = "\033[0m" ;