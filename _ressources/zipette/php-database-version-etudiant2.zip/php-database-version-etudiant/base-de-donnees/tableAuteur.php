<?php

// Table des auteurs
$tableAuteurs = [
    "1" =>["prenom"=>"jean","nom"=>"dupond"],
    "2" =>["prenom"=>"alain","nom"=>"durand"],
    "3" =>["prenom"=>"anne","nom"=>"martin"],
    "4" =>["prenom"=>"marie","nom"=>"thomas"],
    "5" =>["prenom"=>"pierre","nom"=>"sapin"],
];