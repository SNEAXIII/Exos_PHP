<?php

// Table des categories
$tableCategories = [
    "1" =>["libelle"=>"Informatique"],
    "2" =>["libelle"=>"Loisirs"],
    "3" =>["libelle"=>"Musique"],
    "4" =>["libelle"=>"Histoire"]
];

