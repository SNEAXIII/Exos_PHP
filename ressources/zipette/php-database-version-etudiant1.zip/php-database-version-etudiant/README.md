# TP Base de données - Tableaux

---
## Objectif
L'objectif de ce TP est de simuler une **base de données** en utilisant les **tableaux** en **PHP**.    


## Présentation du projet

[Concepts](./documentation/concepts.md)

[Base de données](./documentation/database.md)

[Requêtes](./documentation/requetes.md)











